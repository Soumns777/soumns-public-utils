<template>
    <div>
     App
    </div>
</template>

<script>
export default {
     name:'',
     data() {
        return {

        };
    },
    mounted() {

    },
    methods: {

    },
};
</script>

<style scoped lang='scss'>
</style>
